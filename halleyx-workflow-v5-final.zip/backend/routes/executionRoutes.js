const router = require('express').Router();
const ctrl   = require('../controllers/executionController');

// POST   /api/workflows/:workflow_id/execute
router.post('/workflows/:workflow_id/execute', ctrl.execute);

// GET    /api/executions
router.get('/executions', ctrl.getAll);

// GET    /api/executions/:id
router.get('/executions/:id', ctrl.getOne);

// POST   /api/executions/:id/cancel
router.post('/executions/:id/cancel', ctrl.cancel);

// POST   /api/executions/:id/retry
router.post('/executions/:id/retry', ctrl.retry);

module.exports = router;
