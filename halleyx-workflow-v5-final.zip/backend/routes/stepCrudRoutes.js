const router = require('express').Router();
const ctrl   = require('../controllers/stepController');

// PUT    /api/steps/:id
// DELETE /api/steps/:id
router.put('/:id',    ctrl.update);
router.delete('/:id', ctrl.remove);

module.exports = router;
