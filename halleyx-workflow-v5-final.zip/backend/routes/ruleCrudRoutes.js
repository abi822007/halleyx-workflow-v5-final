const router = require('express').Router();
const ctrl   = require('../controllers/ruleController');

// PUT    /api/rules/:id
// DELETE /api/rules/:id
// POST   /api/rules/test
router.post('/test',  ctrl.test);
router.put('/:id',    ctrl.update);
router.delete('/:id', ctrl.remove);

module.exports = router;
