const router = require('express').Router();
const ctrl   = require('../controllers/stepController');

// POST   /api/workflows/:workflow_id/steps
// GET    /api/workflows/:workflow_id/steps
router.post('/:workflow_id/steps', ctrl.create);
router.get('/:workflow_id/steps',  ctrl.getByWorkflow);

module.exports = router;
