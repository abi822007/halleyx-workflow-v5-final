const router = require('express').Router();
const ctrl   = require('../controllers/ruleController');

// POST   /api/steps/:step_id/rules
// GET    /api/steps/:step_id/rules
router.post('/:step_id/rules', ctrl.create);
router.get('/:step_id/rules',  ctrl.getByStep);

module.exports = router;
