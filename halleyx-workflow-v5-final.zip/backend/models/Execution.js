const mongoose = require('mongoose');

const LogEntrySchema = new mongoose.Schema(
  {
    step_id:            String,
    step_name:          String,
    step_type:          String,
    status:             { type: String, default: 'completed' },
    message:            String,
    evaluated_rules:    { type: Array, default: [] },
    selected_next_step: String,
    rule_error:         String,
    duration_ms:        Number,
    timestamp:          { type: Date, default: Date.now },
  },
  { _id: false }
);

const ExecutionSchema = new mongoose.Schema(
  {
    id:               { type: String, required: true, unique: true },
    workflow_id:      { type: String, required: true, index: true },
    workflow_version: { type: Number },
    // Fix #6: align status enum with spec (pending, in_progress, completed, failed, canceled)
    status: {
      type: String,
      enum: ['pending', 'in_progress', 'completed', 'failed', 'canceled', 'cancelled'],
      default: 'pending',
    },
    data:             { type: Object, default: {} },
    logs:             { type: [LogEntrySchema], default: [] },
    current_step_id:  { type: String, default: null },
    // Fix #5: track which step failed for targeted retry
    failed_step_id:   { type: String, default: null },
    retries:          { type: Number, default: 0 },
    triggered_by:     { type: String, default: 'user' },
    started_at:       { type: Date, default: Date.now },
    ended_at:         { type: Date, default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Execution', ExecutionSchema);
