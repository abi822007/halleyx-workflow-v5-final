const mongoose = require('mongoose');

const StepSchema = new mongoose.Schema({
  id:          { type: String, required: true, unique: true },
  workflow_id: { type: String, required: true, index: true },
  name:        { type: String, required: true, trim: true },
  step_type:   { type: String, enum: ['task', 'approval', 'notification'], required: true },
  order:       { type: Number, required: true },
  metadata:    { type: Object, default: {} },
});

module.exports = mongoose.model('Step', StepSchema);
