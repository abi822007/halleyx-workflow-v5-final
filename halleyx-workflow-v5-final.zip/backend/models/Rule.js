const mongoose = require('mongoose');

const RuleSchema = new mongoose.Schema({
  id:           { type: String, required: true, unique: true },
  step_id:      { type: String, required: true, index: true },
  condition:    { type: String, required: true },
  next_step_id: { type: String, default: null },
  priority:     { type: Number, default: 10 },
});

module.exports = mongoose.model('Rule', RuleSchema);
