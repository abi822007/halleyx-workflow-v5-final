const mongoose = require('mongoose');

const WorkflowSchema = new mongoose.Schema(
  {
    id:            { type: String, required: true, unique: true },
    name:          { type: String, required: true, trim: true },
    version:       { type: Number, default: 1 },
    is_active:     { type: Boolean, default: true },
    input_schema:  { type: Object, default: {} },
    start_step_id: { type: String, default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Workflow', WorkflowSchema);
