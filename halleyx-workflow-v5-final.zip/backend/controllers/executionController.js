const Execution  = require('../models/Execution');
const { runWorkflow, retryFromFailedStep } = require('../services/executionEngine');

// POST /api/workflows/:workflow_id/execute
exports.execute = async (req, res, next) => {
  try {
    const { workflow_id } = req.params;
    runWorkflow(workflow_id, req.body).catch(err => console.error('Engine error:', err.message));
    await new Promise(r => setTimeout(r, 120));
    const exec = await Execution.findOne({ workflow_id }).sort({ createdAt: -1 });
    res.status(202).json({ execution_id: exec?.id, status: 'in_progress', message: 'Execution started' });
  } catch (e) { next(e); }
};

// GET /api/executions
exports.getAll = async (req, res, next) => {
  try {
    const { workflow_id, status, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (workflow_id) filter.workflow_id = workflow_id;
    if (status)      filter.status = status;
    const [executions, total] = await Promise.all([
      Execution.find(filter).sort({ createdAt: -1 }).skip((page-1)*limit).limit(Number(limit)),
      Execution.countDocuments(filter),
    ]);
    res.json({ executions, total, page: Number(page), limit: Number(limit) });
  } catch (e) { next(e); }
};

// GET /api/executions/:id
exports.getOne = async (req, res, next) => {
  try {
    const exec = await Execution.findOne({ id: req.params.id });
    if (!exec) return res.status(404).json({ error: 'Execution not found' });
    res.json(exec);
  } catch (e) { next(e); }
};

// POST /api/executions/:id/cancel
exports.cancel = async (req, res, next) => {
  try {
    const exec = await Execution.findOneAndUpdate(
      { id: req.params.id, status: 'in_progress' },
      { status: 'canceled', ended_at: new Date() },
      { new: true }
    );
    if (!exec) return res.status(404).json({ error: 'In-progress execution not found' });
    res.json({ message: 'Execution canceled', execution: exec });
  } catch (e) { next(e); }
};

// POST /api/executions/:id/retry  — Fix #5: only retries the failed step
exports.retry = async (req, res, next) => {
  try {
    const exec = await Execution.findOne({ id: req.params.id });
    if (!exec) return res.status(404).json({ error: 'Execution not found' });
    if (exec.status !== 'failed') return res.status(400).json({ error: 'Only failed executions can be retried' });

    retryFromFailedStep(exec.id).catch(err => console.error('Retry error:', err.message));
    await new Promise(r => setTimeout(r, 120));

    res.status(202).json({
      execution_id: exec.id,
      status: 'in_progress',
      message: `Retrying from failed step (retry #${exec.retries + 1})`,
    });
  } catch (e) { next(e); }
};
