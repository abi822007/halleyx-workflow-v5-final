const Workflow = require('../models/Workflow');
const Step     = require('../models/Step');
const Rule     = require('../models/Rule');
const { v4: uuidv4 } = require('uuid');

// POST /api/workflows
exports.create = async (req, res, next) => {
  try {
    const { name, input_schema, is_active } = req.body;
    if (!name) return res.status(400).json({ error: 'name is required' });
    const wf = new Workflow({
      id: uuidv4(), name, input_schema: input_schema || {}, is_active: is_active ?? true,
    });
    await wf.save();
    res.status(201).json(wf);
  } catch (e) { next(e); }
};

// GET /api/workflows
exports.getAll = async (req, res, next) => {
  try {
    const { search, page = 1, limit = 20 } = req.query;
    const filter = search ? { name: { $regex: search, $options: 'i' } } : {};
    const [workflows, total] = await Promise.all([
      Workflow.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(Number(limit)),
      Workflow.countDocuments(filter),
    ]);
    res.json({ workflows, total, page: Number(page), limit: Number(limit) });
  } catch (e) { next(e); }
};

// GET /api/workflows/:id
exports.getOne = async (req, res, next) => {
  try {
    const wf = await Workflow.findOne({ id: req.params.id });
    if (!wf) return res.status(404).json({ error: 'Workflow not found' });
    res.json(wf);
  } catch (e) { next(e); }
};

// PUT /api/workflows/:id
exports.update = async (req, res, next) => {
  try {
    const { name, input_schema, is_active, start_step_id } = req.body;
    const wf = await Workflow.findOneAndUpdate(
      { id: req.params.id },
      { $set: { name, input_schema, is_active, start_step_id }, $inc: { version: 1 } },
      { new: true, runValidators: true }
    );
    if (!wf) return res.status(404).json({ error: 'Workflow not found' });
    res.json(wf);
  } catch (e) { next(e); }
};

// DELETE /api/workflows/:id
exports.remove = async (req, res, next) => {
  try {
    const wf = await Workflow.findOneAndDelete({ id: req.params.id });
    if (!wf) return res.status(404).json({ error: 'Workflow not found' });
    const steps = await Step.find({ workflow_id: req.params.id });
    const stepIds = steps.map((s) => s.id);
    await Step.deleteMany({ workflow_id: req.params.id });
    await Rule.deleteMany({ step_id: { $in: stepIds } });
    res.json({ message: 'Workflow and all related data deleted' });
  } catch (e) { next(e); }
};
