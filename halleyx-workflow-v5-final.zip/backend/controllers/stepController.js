const Step     = require('../models/Step');
const Rule     = require('../models/Rule');
const Workflow = require('../models/Workflow');
const { v4: uuidv4 } = require('uuid');

// POST /api/workflows/:workflow_id/steps
exports.create = async (req, res, next) => {
  try {
    const { workflow_id } = req.params;
    const wf = await Workflow.findOne({ id: workflow_id });
    if (!wf) return res.status(404).json({ error: 'Workflow not found' });

    const { name, step_type, order, metadata } = req.body;
    if (!name || !step_type) return res.status(400).json({ error: 'name and step_type are required' });

    const stepCount = await Step.countDocuments({ workflow_id });
    const step = new Step({
      id: uuidv4(), workflow_id, name, step_type,
      order: order ?? stepCount + 1,
      metadata: metadata || {},
    });
    await step.save();

    // Auto-set start_step_id on first step
    if (stepCount === 0) {
      await Workflow.updateOne({ id: workflow_id }, { start_step_id: step.id });
    }

    res.status(201).json(step);
  } catch (e) { next(e); }
};

// GET /api/workflows/:workflow_id/steps
exports.getByWorkflow = async (req, res, next) => {
  try {
    const steps = await Step.find({ workflow_id: req.params.workflow_id }).sort({ order: 1 });
    res.json(steps);
  } catch (e) { next(e); }
};

// PUT /api/steps/:id
exports.update = async (req, res, next) => {
  try {
    const { name, step_type, order, metadata } = req.body;
    const step = await Step.findOneAndUpdate(
      { id: req.params.id },
      { $set: { name, step_type, order, metadata } },
      { new: true, runValidators: true }
    );
    if (!step) return res.status(404).json({ error: 'Step not found' });
    res.json(step);
  } catch (e) { next(e); }
};

// DELETE /api/steps/:id
exports.remove = async (req, res, next) => {
  try {
    const step = await Step.findOneAndDelete({ id: req.params.id });
    if (!step) return res.status(404).json({ error: 'Step not found' });
    await Rule.deleteMany({ step_id: req.params.id });
    res.json({ message: 'Step and its rules deleted' });
  } catch (e) { next(e); }
};
