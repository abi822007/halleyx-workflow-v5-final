const Rule = require('../models/Rule');
const Step = require('../models/Step');
const { v4: uuidv4 } = require('uuid');
const { evaluateCondition, runRuleEngine } = require('../services/ruleEngine');

// POST /api/steps/:step_id/rules
exports.create = async (req, res, next) => {
  try {
    const { step_id } = req.params;
    const step = await Step.findOne({ id: step_id });
    if (!step) return res.status(404).json({ error: 'Step not found' });

    const { condition, next_step_id, priority } = req.body;
    if (!condition) return res.status(400).json({ error: 'condition is required' });

    const rule = new Rule({
      id: uuidv4(), step_id, condition,
      next_step_id: next_step_id || null,
      priority: priority ?? 10,
    });
    await rule.save();
    res.status(201).json(rule);
  } catch (e) { next(e); }
};

// GET /api/steps/:step_id/rules
exports.getByStep = async (req, res, next) => {
  try {
    const rules = await Rule.find({ step_id: req.params.step_id }).sort({ priority: 1 });
    res.json(rules);
  } catch (e) { next(e); }
};

// PUT /api/rules/:id
exports.update = async (req, res, next) => {
  try {
    const { condition, next_step_id, priority } = req.body;
    const rule = await Rule.findOneAndUpdate(
      { id: req.params.id },
      { $set: { condition, next_step_id, priority } },
      { new: true }
    );
    if (!rule) return res.status(404).json({ error: 'Rule not found' });
    res.json(rule);
  } catch (e) { next(e); }
};

// DELETE /api/rules/:id
exports.remove = async (req, res, next) => {
  try {
    const rule = await Rule.findOneAndDelete({ id: req.params.id });
    if (!rule) return res.status(404).json({ error: 'Rule not found' });
    res.json({ message: 'Rule deleted' });
  } catch (e) { next(e); }
};

// POST /api/rules/test
exports.test = async (req, res, next) => {
  try {
    const { condition, data } = req.body;
    if (!condition) return res.status(400).json({ error: 'condition is required' });
    const result = evaluateCondition(condition, data || {});
    res.json({ condition, data, result });
  } catch (e) { next(e); }
};
