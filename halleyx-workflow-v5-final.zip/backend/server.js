const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();

// ── Middleware ──────────────────────────────────────────────
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.options('*', cors());
app.use(express.json());

// Request logger
app.use((req, _res, next) => {
  console.log(`[${req.method}] ${req.url}`);
  next();
});

// ── Routes ──────────────────────────────────────────────────
app.use('/api/workflows', require('./routes/workflowRoutes'));
app.use('/api/workflows', require('./routes/stepRoutes'));
app.use('/api/steps',     require('./routes/stepCrudRoutes'));
app.use('/api/steps',     require('./routes/ruleRoutes'));
app.use('/api/rules',     require('./routes/ruleCrudRoutes'));
app.use('/api',           require('./routes/executionRoutes'));

// ── Health check ─────────────────────────────────────────────
app.get('/api/health', (_req, res) =>
  res.json({ status: 'ok', time: new Date() })
);

// ── 404 ──────────────────────────────────────────────────────
app.use((_req, res) => res.status(404).json({ error: 'Route not found' }));

// ── Error handler ────────────────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error('ERROR:', err.message);
  res.status(500).json({ error: err.message || 'Internal Server Error' });
});

// ── Connect & Start ──────────────────────────────────────────
const PORT = process.env.PORT || 5000;

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log('✅  MongoDB connected');
    const server = app.listen(PORT, () =>
      console.log(`🚀  Server running → http://localhost:${PORT}`)
    );

    // Graceful shutdown — prevents EADDRINUSE on restart
    process.on('SIGTERM', () => { server.close(); process.exit(0); });
    process.on('SIGINT',  () => { server.close(); process.exit(0); });
  })
  .catch((err) => {
    console.error('❌  MongoDB error:', err.message);
    process.exit(1);
  });

module.exports = app;
