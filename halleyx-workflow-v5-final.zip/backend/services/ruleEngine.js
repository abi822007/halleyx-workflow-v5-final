/**
 * ─────────────────────────────────────────────
 *  Halleyx Rule Engine
 * ─────────────────────────────────────────────
 *  Supports:
 *   Comparisons : ==  !=  >  <  >=  <=
 *   Logic       : &&  ||
 *   String fns  : contains(field, value)
 *                 startsWith(field, value)
 *                 endsWith(field, value)
 *   Fallback    : DEFAULT  (always matches)
 * ─────────────────────────────────────────────
 */

/**
 * Evaluate a single condition string against execution data.
 * @param {string} condition
 * @param {object} data
 * @returns {boolean | { error: string }}
 */
function evaluateCondition(condition, data = {}) {
  if (!condition || condition.trim() === 'DEFAULT') return true;

  try {
    // Translate helper functions → plain JS expressions
    let expr = condition
      .replace(/contains\(([^,]+),\s*([^)]+)\)/g,   '(String($1).includes($2))')
      .replace(/startsWith\(([^,]+),\s*([^)]+)\)/g, '(String($1).startsWith($2))')
      .replace(/endsWith\(([^,]+),\s*([^)]+)\)/g,   '(String($1).endsWith($2))');

    const keys = Object.keys(data);
    const vals = Object.values(data);

    // eslint-disable-next-line no-new-func
    const fn = new Function(...keys, `"use strict"; return !!(${expr});`);
    return fn(...vals);
  } catch (e) {
    return { error: e.message };
  }
}

/**
 * Run all rules for a step against execution data.
 *
 * - Rules sorted ascending by priority (lowest = first).
 * - First rule whose condition is true is selected.
 * - Falls back to DEFAULT if nothing else matched.
 *
 * @param {Array}  rules  Array of Rule documents
 * @param {object} data   Execution data / context
 * @returns {{ selected: object|null, log: Array, error?: string }}
 */
function runRuleEngine(rules, data = {}) {
  const sorted = [...rules].sort((a, b) => (a.priority ?? 99) - (b.priority ?? 99));
  const log = [];

  for (const rule of sorted) {
    const result = evaluateCondition(rule.condition, data);

    // Handle evaluation error (broken expression) — log and continue
    if (result && typeof result === 'object' && result.error) {
      log.push({
        rule: { id: rule.id, condition: rule.condition, priority: rule.priority },
        result: 'error',
        error: result.error,
      });
      continue;
    }

    log.push({
      rule: { id: rule.id, condition: rule.condition, priority: rule.priority },
      result: result ? 'matched' : 'skipped',
    });

    if (result === true) return { selected: rule, log };
  }

  // Nothing matched — look for explicit DEFAULT rule
  const defaultRule = sorted.find((r) => r.condition?.trim() === 'DEFAULT');
  if (defaultRule) {
    log.push({
      rule: { id: defaultRule.id, condition: 'DEFAULT', priority: defaultRule.priority },
      result: 'matched (fallback)',
    });
    return { selected: defaultRule, log };
  }

  return {
    selected: null,
    log,
    error: 'No matching rule and no DEFAULT rule defined.',
  };
}

module.exports = { evaluateCondition, runRuleEngine };
