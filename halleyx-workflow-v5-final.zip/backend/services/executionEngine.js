const Execution = require('../models/Execution');
const Step      = require('../models/Step');
const Rule      = require('../models/Rule');
const Workflow  = require('../models/Workflow');
const { runRuleEngine } = require('./ruleEngine');
const { v4: uuidv4 }   = require('uuid');

const delay = (ms = 500) => new Promise((r) => setTimeout(r, ms));

async function executeStep(step) {
  await delay(300 + Math.random() * 400);
  switch (step.step_type) {
    case 'approval':
      return { message: `[APPROVAL] Auto-approved: "${step.name}"` };
    case 'notification':
      return { message: step.metadata?.message ? `[NOTIFY] ${step.metadata.message}` : `[NOTIFY] Notification sent for: "${step.name}"` };
    case 'task':
    default:
      return { message: `[TASK] Executed: "${step.name}"` };
  }
}

/**
 * Run full workflow from start_step_id
 */
async function runWorkflow(workflowId, inputData = {}) {
  const wf = await Workflow.findOne({ id: workflowId });
  if (!wf)               throw new Error('Workflow not found');
  if (!wf.start_step_id) throw new Error('Workflow has no start step defined');

  const exec = new Execution({
    id: uuidv4(), workflow_id: wf.id, workflow_version: wf.version,
    // Fix #6: use in_progress instead of running
    status: 'in_progress', data: inputData, triggered_by: 'user',
    started_at: new Date(),
  });
  await exec.save();

  await _runFromStep(exec, wf, wf.start_step_id, inputData);
  return Execution.findOne({ id: exec.id });
}

/**
 * Fix #5: Retry only the failed step, then continue from there
 */
async function retryFromFailedStep(executionId) {
  const exec = await Execution.findOne({ id: executionId });
  if (!exec) throw new Error('Execution not found');

  const wf = await Workflow.findOne({ id: exec.workflow_id });
  if (!wf)   throw new Error('Workflow not found');

  // Find which step failed
  const failedStepId = exec.failed_step_id || exec.current_step_id;
  if (!failedStepId) throw new Error('No failed step found to retry');

  // Increment retries counter
  await Execution.updateOne({ id: executionId }, {
    status: 'in_progress',
    $inc: { retries: 1 },
  });

  // Remove logs from the failed step onwards (clean slate for retry)
  const failedLogIndex = exec.logs.findIndex(l => l.step_id === failedStepId);
  const cleanedLogs = failedLogIndex >= 0 ? exec.logs.slice(0, failedLogIndex) : exec.logs;
  await Execution.updateOne({ id: executionId }, { logs: cleanedLogs });

  // Re-run from the failed step only
  const freshExec = await Execution.findOne({ id: executionId });
  await _runFromStep(freshExec, wf, failedStepId, exec.data);
  return Execution.findOne({ id: executionId });
}

/**
 * Core step runner — shared by runWorkflow and retryFromFailedStep
 */
async function _runFromStep(exec, wf, startStepId, inputData) {
  let stepId   = startStepId;
  const visited = {};
  let maxIter   = 50;

  try {
    while (stepId && maxIter-- > 0) {
      if (visited[stepId]) {
        exec.logs.push({ step_id: stepId, step_name: '(loop guard)', step_type: 'task', status: 'warning', message: `Loop detected at step ${stepId} — halted.`, timestamp: new Date() });
        break;
      }
      visited[stepId] = true;

      const step = await Step.findOne({ id: stepId });
      if (!step) {
        exec.logs.push({ step_id: stepId, step_name: '(missing)', status: 'error', message: `Step "${stepId}" not found.`, timestamp: new Date() });
        exec.status = 'failed';
        exec.failed_step_id = stepId;
        break;
      }

      await Execution.updateOne({ id: exec.id }, { current_step_id: stepId });

      const start = Date.now();
      const { message } = await executeStep(step);

      const stepLog = {
        step_id: stepId, step_name: step.name, step_type: step.step_type,
        status: 'completed', message,
        evaluated_rules: [], selected_next_step: null,
        duration_ms: Date.now() - start,
        timestamp: new Date(),
      };

      const rules = await Rule.find({ step_id: stepId }).sort({ priority: 1 });
      if (rules.length > 0) {
        const { selected, log, error } = runRuleEngine(rules, inputData);
        stepLog.evaluated_rules    = log;
        stepLog.selected_next_step = selected?.next_step_id || null;
        if (error && !selected) {
          stepLog.rule_error  = error;
          stepLog.status      = 'error';
          exec.logs.push(stepLog);
          exec.status         = 'failed';
          exec.failed_step_id = stepId;
          break;
        }
        stepId = selected?.next_step_id || null;
      } else {
        const nextStep = await Step.findOne({ workflow_id: wf.id, order: step.order + 1 });
        stepLog.selected_next_step = nextStep?.id || null;
        stepId = nextStep?.id || null;
      }

      exec.logs.push(stepLog);
      await Execution.updateOne({ id: exec.id }, { logs: exec.logs, current_step_id: stepId });
    }

    if (exec.status === 'in_progress') {
      exec.status = exec.logs.some(l => l.status === 'error') ? 'failed' : 'completed';
    }
  } catch (err) {
    exec.status = 'failed';
    exec.logs.push({ step_name: 'engine', status: 'error', message: err.message, timestamp: new Date() });
  }

  await Execution.updateOne(
    { id: exec.id },
    { status: exec.status, current_step_id: null, failed_step_id: exec.failed_step_id || null, logs: exec.logs, ended_at: new Date() }
  );
}

module.exports = { runWorkflow, retryFromFailedStep };
