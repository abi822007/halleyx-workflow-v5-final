# ⚡ Halleyx – Workflow Automation Engine

A full-stack workflow automation system with a visual editor, dynamic rule engine, real-time execution tracking, and audit logs.

---

## 📁 Project Structure

```
halleyx-workflow/
├── backend/                  ← Node.js + Express + MongoDB
│   ├── server.js
│   ├── .env
│   ├── models/
│   │   ├── Workflow.js
│   │   ├── Step.js
│   │   ├── Rule.js
│   │   └── Execution.js
│   ├── controllers/
│   │   ├── workflowController.js
│   │   ├── stepController.js
│   │   ├── ruleController.js
│   │   └── executionController.js
│   ├── routes/
│   │   ├── workflowRoutes.js
│   │   ├── stepRoutes.js
│   │   ├── stepCrudRoutes.js
│   │   ├── ruleRoutes.js
│   │   ├── ruleCrudRoutes.js
│   │   └── executionRoutes.js
│   └── services/
│       ├── ruleEngine.js       ← JSON rule evaluator
│       └── executionEngine.js  ← Workflow runner
│
└── frontend/                 ← React + Vite + Tailwind CSS
    ├── index.html
    ├── vite.config.js
    └── src/
        ├── App.jsx
        ├── main.jsx
        ├── index.css
        ├── services/
        │   └── api.js          ← Axios API client
        ├── context/
        │   └── ToastContext.jsx
        ├── components/
        │   ├── UI.jsx          ← Shared components
        │   └── FlowVisualizer.jsx
        └── pages/
            ├── WorkflowListPage.jsx
            ├── WorkflowEditorPage.jsx
            ├── RuleEditorPage.jsx
            ├── ExecutionPage.jsx
            └── AuditLogsPage.jsx
```

---

## 🚀 Quick Start

### Prerequisites
- **Node.js** v18+ → https://nodejs.org
- **MongoDB** running locally on port 27017
  - Install: https://www.mongodb.com/try/download/community
  - Or use MongoDB Atlas free tier (update MONGO_URI in backend/.env)

---

### 1 – Backend

```bash
cd halleyx-workflow/backend
npm install
npm run dev
```

Server starts at → **http://localhost:5000**

> To use MongoDB Atlas, edit `backend/.env`:
> ```
> MONGO_URI=mongodb+srv://<user>:<pass>@cluster.mongodb.net/halleyx
> ```

---

### 2 – Frontend

Open a second terminal:

```bash
cd halleyx-workflow/frontend
npm install
npm run dev
```

App opens at → **http://localhost:5173**

---

## 🔌 API Reference

### Workflows
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/workflows | Create workflow |
| GET | /api/workflows | List all (search, page, limit) |
| GET | /api/workflows/:id | Get one |
| PUT | /api/workflows/:id | Update + bump version |
| DELETE | /api/workflows/:id | Delete + cascade |

### Steps
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/workflows/:id/steps | Add step |
| GET | /api/workflows/:id/steps | List steps |
| PUT | /api/steps/:id | Update step |
| DELETE | /api/steps/:id | Delete step + rules |

### Rules
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/steps/:id/rules | Add rule |
| GET | /api/steps/:id/rules | List rules |
| PUT | /api/rules/:id | Update rule |
| DELETE | /api/rules/:id | Delete rule |
| POST | /api/rules/test | Test a condition |

### Executions
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/workflows/:id/execute | Run workflow |
| GET | /api/executions | List all executions |
| GET | /api/executions/:id | Get execution + logs |
| POST | /api/executions/:id/cancel | Cancel |
| POST | /api/executions/:id/retry | Retry |

---

## ⚙️ Rule Engine

Conditions are evaluated dynamically using a safe expression evaluator.

### Supported Syntax

```
# Comparison
status == 'approved'
amount > 1000
age >= 18

# Logic
department == 'Engineering' && role == 'Senior'
status == 'active' || status == 'pending'

# String functions
contains(email, '@company.com')
startsWith(name, 'Admin')
endsWith(filename, '.pdf')

# Default fallback (always matches)
DEFAULT
```

### Rule Priority
- Rules are sorted by `priority` ascending (lower number = evaluated first)
- First matching rule wins
- `DEFAULT` rule acts as fallback if nothing matches
- Always define a DEFAULT rule to avoid dead ends

---

## 🧪 Sample Workflow JSON

```json
{
  "name": "Employee Onboarding",
  "input_schema": {
    "name": "string",
    "department": "string",
    "role": "string"
  }
}
```

**Execute with:**
```json
{ "name": "Alice", "department": "Engineering", "role": "Senior" }
```

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, Tailwind CSS, React Router |
| Backend | Node.js, Express.js |
| Database | MongoDB, Mongoose |
| HTTP Client | Axios |
| IDs | UUID v4 |

---

## 📄 License

MIT – Halleyx Challenge 2026
