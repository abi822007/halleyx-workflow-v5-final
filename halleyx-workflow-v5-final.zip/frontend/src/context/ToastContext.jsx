import { createContext, useContext, useState, useCallback } from 'react'
import { v4 as uuidv4 } from 'uuid'

const ToastContext = createContext(null)

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([])

  const toast = useCallback((msg, type = 'info') => {
    const id = uuidv4()
    setToasts(p => [...p, { id, msg, type }])
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3500)
  }, [])

  const remove = useCallback(id => setToasts(p => p.filter(t => t.id !== id)), [])

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      {/* Toast UI */}
      <div style={{ position: 'fixed', bottom: 24, right: 24, zIndex: 9999, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {toasts.map(t => (
          <div
            key={t.id}
            onClick={() => remove(t.id)}
            className="animate-slide-in"
            style={{
              padding: '10px 18px',
              borderRadius: 8,
              fontSize: 13,
              fontFamily: "'DM Sans', sans-serif",
              background: t.type === 'success' ? '#10B981' : t.type === 'error' ? '#EF4444' : '#1e1e2e',
              color: '#fff',
              cursor: 'pointer',
              maxWidth: 320,
              boxShadow: '0 4px 16px rgba(0,0,0,0.4)',
            }}
          >
            {t.msg}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}

export const useToast = () => useContext(ToastContext)
