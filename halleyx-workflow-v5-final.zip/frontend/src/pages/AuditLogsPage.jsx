import { useState, useEffect } from 'react'
import { executionAPI, workflowAPI } from '../services/api'
import { useToast } from '../context/ToastContext'
import { Card, Btn, Badge, STATUS_COLOR, STEP_TYPE_COLOR, STEP_TYPE_ICON } from '../components/UI'

export default function AuditLogsPage() {
  const { toast } = useToast()
  const [executions,    setExecutions]    = useState([])
  const [workflows,     setWorkflows]     = useState({})
  const [selected,      setSelected]      = useState(null)
  const [loading,       setLoading]       = useState(true)
  const [statusFilter,  setStatusFilter]  = useState('')

  const load = async (status = '') => {
    setLoading(true)
    try {
      const params = { limit: 100 }
      if (status) params.status = status
      const [execRes, wfRes] = await Promise.all([
        executionAPI.getAll(params),
        workflowAPI.getAll({ limit: 100 }),
      ])
      setExecutions(execRes.data.executions)
      const map = {}
      wfRes.data.workflows.forEach(w => { map[w.id] = { name: w.name, version: w.version } })
      setWorkflows(map)
    } catch {
      toast('Failed to load audit logs', 'error')
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleRetry = async (exec) => {
    try {
      await executionAPI.retry(exec.id)
      toast(`Retrying from failed step (retry #${(exec.retries||0)+1})`, 'success')
      setTimeout(() => load(statusFilter), 1200)
    } catch { toast('Retry failed', 'error') }
  }

  const handleCancel = async (execId) => {
    try {
      await executionAPI.cancel(execId)
      toast('Execution canceled', 'success')
      load(statusFilter)
    } catch { toast('Cancel failed', 'error') }
  }

  // Fix filter labels to match spec enum
  const FILTERS = [
    { value: '',            label: 'ALL' },
    { value: 'in_progress', label: 'RUNNING' },
    { value: 'completed',   label: 'COMPLETED' },
    { value: 'failed',      label: 'FAILED' },
    { value: 'canceled',    label: 'CANCELED' },
  ]

  const TH = ({ children, w }) => (
    <th style={{ padding: '10px 14px', textAlign: 'left', fontSize: 11, fontFamily: "'Space Mono',monospace",
      color: '#5555aa', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 400,
      borderBottom: '1px solid #1e1e3a', width: w, whiteSpace: 'nowrap' }}>
      {children}
    </th>
  )
  const TD = ({ children, mono }) => (
    <td style={{ padding: '11px 14px', fontSize: 12, color: '#c0c0e0', verticalAlign: 'middle',
      borderBottom: '1px solid #111128', fontFamily: mono ? "'Space Mono',monospace" : "'DM Sans',sans-serif" }}>
      {children}
    </td>
  )

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 700, fontFamily: "'Space Mono',monospace", color: '#e0e0f8', margin: 0 }}>
            Audit Logs
          </h1>
          <p style={{ fontSize: 13, color: '#5555aa', margin: '4px 0 0' }}>
            {executions.length} executions recorded
          </p>
        </div>
        <Btn variant="secondary" onClick={() => load(statusFilter)}>↻ Refresh</Btn>
      </div>

      {/* Status filters */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {FILTERS.map(f => (
          <button key={f.value} onClick={() => { setStatusFilter(f.value); load(f.value) }}
            style={{
              padding: '5px 14px', borderRadius: 20, fontSize: 11, cursor: 'pointer',
              fontFamily: "'Space Mono',monospace",
              background: statusFilter === f.value ? '#7C3AED' : '#111128',
              color: statusFilter === f.value ? '#fff' : '#7070a0',
              border: `1px solid ${statusFilter === f.value ? '#7C3AED' : '#2a2a3e'}`,
              textTransform: 'uppercase', letterSpacing: '0.05em',
            }}>
            {f.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ color: '#5555aa', textAlign: 'center', padding: 48 }}>Loading...</div>
      ) : executions.length === 0 ? (
        <Card style={{ textAlign: 'center', padding: 56 }}>
          <div style={{ fontSize: 36, marginBottom: 12 }}>📋</div>
          <div style={{ color: '#555' }}>No executions yet. Run a workflow to see logs here.</div>
        </Card>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

          {/* Fix: Full audit table matching spec columns */}
          <Card style={{ padding: 0, overflow: 'hidden' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead style={{ background: '#0d0d1a' }}>
                <tr>
                  <TH w="130px">Execution ID</TH>
                  <TH>Workflow</TH>
                  <TH w="80px">Version</TH>
                  <TH w="110px">Status</TH>
                  <TH w="100px">Started By</TH>
                  <TH w="150px">Start Time</TH>
                  <TH w="150px">End Time</TH>
                  <TH w="150px">Actions</TH>
                </tr>
              </thead>
              <tbody>
                {executions.map(exec => {
                  const wf    = workflows[exec.workflow_id] || {}
                  const color = STATUS_COLOR[exec.status] || '#6B7280'
                  const isSelected = selected?.id === exec.id
                  return (
                    <tr key={exec.id}
                      style={{ background: isSelected ? '#12122a' : 'transparent', transition: 'background 0.15s', cursor: 'pointer' }}
                      onClick={() => setSelected(isSelected ? null : exec)}
                      onMouseEnter={e => { if (!isSelected) e.currentTarget.style.background='#0d0d1a' }}
                      onMouseLeave={e => { if (!isSelected) e.currentTarget.style.background='transparent' }}>
                      <TD mono>
                        <span style={{ color: '#5555aa', fontSize: 11 }} title={exec.id}>
                          {exec.id.slice(0,8)}...
                        </span>
                      </TD>
                      <TD>
                        <span style={{ fontWeight: 600, color: '#d0d0f8' }}>{wf.name || '—'}</span>
                      </TD>
                      <TD mono>
                        <Badge color="#7C3AED">v{exec.workflow_version || wf.version || 1}</Badge>
                      </TD>
                      <TD>
                        <Badge color={color}>{exec.status}</Badge>
                      </TD>
                      <TD mono>
                        <span style={{ color: '#8080c0', fontSize: 11 }}>{exec.triggered_by || 'user'}</span>
                      </TD>
                      <TD mono>
                        <span style={{ fontSize: 11 }}>
                          {exec.started_at ? new Date(exec.started_at).toLocaleString() : new Date(exec.createdAt).toLocaleString()}
                        </span>
                      </TD>
                      <TD mono>
                        <span style={{ fontSize: 11, color: exec.ended_at ? '#c0c0e0' : '#5555aa' }}>
                          {exec.ended_at ? new Date(exec.ended_at).toLocaleString() : '—'}
                        </span>
                      </TD>
                      <TD>
                        <div style={{ display: 'flex', gap: 6 }} onClick={e => e.stopPropagation()}>
                          <Btn small variant="secondary" onClick={() => setSelected(isSelected ? null : exec)}>
                            View Logs
                          </Btn>
                          {exec.status === 'failed' && (
                            <Btn small variant="secondary" onClick={() => handleRetry(exec)}>Retry</Btn>
                          )}
                          {exec.status === 'in_progress' && (
                            <Btn small variant="danger" onClick={() => handleCancel(exec.id)}>Cancel</Btn>
                          )}
                        </div>
                      </TD>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </Card>

          {/* Detail / log panel */}
          {selected && (
            <Card>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#d0d0f8', fontFamily: "'DM Sans',sans-serif" }}>
                  Execution Logs — {workflows[selected.workflow_id]?.name}
                  <span style={{ fontSize: 11, color: '#5555aa', fontFamily: "'Space Mono',monospace", marginLeft: 10 }}>
                    {selected.id}
                  </span>
                </div>
                <button onClick={() => setSelected(null)}
                  style={{ background: 'none', border: 'none', color: '#7070a0', cursor: 'pointer', fontSize: 18 }}>×</button>
              </div>

              {/* Input data */}
              {Object.keys(selected.data || {}).length > 0 && (
                <div style={{ marginBottom: 16 }}>
                  <div style={{ fontSize: 11, color: '#7070a0', fontFamily: "'Space Mono',monospace",
                    textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 6 }}>Input data</div>
                  <pre style={{ background: '#0a0a18', borderRadius: 6, padding: 12, fontSize: 12,
                    fontFamily: "'Space Mono',monospace", color: '#8080c0', margin: 0, overflowX: 'auto' }}>
                    {JSON.stringify(selected.data, null, 2)}
                  </pre>
                </div>
              )}

              {/* Step logs */}
              <div style={{ fontSize: 11, color: '#7070a0', fontFamily: "'Space Mono',monospace",
                textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 10 }}>
                Step logs ({selected.logs?.length || 0} steps)
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {selected.logs?.map((log, i) => (
                  <div key={i} style={{ background: '#0a0a18', borderRadius: 8, padding: '10px 14px',
                    border: `1px solid ${log.status==='error' ? '#EF444433' : '#1a1a30'}` }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <span style={{ fontSize: 14, color: STEP_TYPE_COLOR[log.step_type] }}>
                        {STEP_TYPE_ICON[log.step_type]}
                      </span>
                      <span style={{ fontSize: 13, fontWeight: 600, color: '#d0d0f8', fontFamily: "'DM Sans',sans-serif" }}>
                        {log.step_name}
                      </span>
                      <Badge color={log.status==='error'?'#EF4444':log.status==='warning'?'#F59E0B':'#10B981'}>
                        {log.status}
                      </Badge>
                      {log.duration_ms && (
                        <span style={{ fontSize: 10, color: '#5555aa', fontFamily: "'Space Mono',monospace" }}>
                          {log.duration_ms}ms
                        </span>
                      )}
                      <span style={{ marginLeft: 'auto', fontSize: 10, color: '#5555aa', fontFamily: "'Space Mono',monospace" }}>
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    {log.message && (
                      <div style={{ fontSize: 11, color: '#7070a0', fontFamily: "'Space Mono',monospace", marginBottom: 4 }}>
                        {log.message}
                      </div>
                    )}
                    {log.evaluated_rules?.length > 0 && (
                      <div style={{ marginTop: 6, paddingTop: 6, borderTop: '1px solid #1a1a30' }}>
                        <div style={{ fontSize: 10, color: '#5555aa', fontFamily: "'Space Mono',monospace",
                          textTransform: 'uppercase', marginBottom: 4 }}>Rules evaluated</div>
                        {log.evaluated_rules.map((r, j) => (
                          <div key={j} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11,
                            fontFamily: "'Space Mono',monospace", color: '#7070a0', marginBottom: 2 }}>
                            <span style={{ color: r.result==='matched'||r.result?.includes('matched')?'#10B981':r.result==='error'?'#EF4444':'#444466', fontSize: 14 }}>
                              {r.result==='matched'||r.result?.includes('matched') ? '✓' : r.result==='error' ? '✗' : '○'}
                            </span>
                            <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                              {r.rule?.condition}
                            </span>
                            <Badge color={r.result==='matched'||r.result?.includes('matched')?'#10B981':r.result==='error'?'#EF4444':'#6B7280'}>
                              {r.result}
                            </Badge>
                          </div>
                        ))}
                        {log.selected_next_step && (
                          <div style={{ fontSize: 11, color: '#7C3AED', fontFamily: "'Space Mono',monospace", marginTop: 4 }}>
                            → next: {log.selected_next_step.slice(0,8)}...
                          </div>
                        )}
                      </div>
                    )}
                    {log.rule_error && (
                      <div style={{ fontSize: 11, color: '#EF4444', fontFamily: "'Space Mono',monospace", marginTop: 4 }}>
                        Rule error: {log.rule_error}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      )}
    </div>
  )
}
