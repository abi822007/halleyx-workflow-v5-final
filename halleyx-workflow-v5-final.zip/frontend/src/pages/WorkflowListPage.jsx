import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { workflowAPI, stepAPI } from '../services/api'
import { useToast } from '../context/ToastContext'
import { Card, Btn, Badge, Input, Label } from '../components/UI'

export default function WorkflowListPage() {
  const navigate = useNavigate()
  const { toast } = useToast()

  const [workflows,   setWorkflows]   = useState([])
  const [stepCounts,  setStepCounts]  = useState({})
  const [total,       setTotal]       = useState(0)
  const [search,      setSearch]      = useState('')
  const [loading,     setLoading]     = useState(true)
  const [showCreate,  setShowCreate]  = useState(false)
  const [newName,     setNewName]     = useState('')
  const [creating,    setCreating]    = useState(false)

  const load = async (q = '') => {
    setLoading(true)
    try {
      const { data } = await workflowAPI.getAll({ search: q, limit: 50 })
      setWorkflows(data.workflows)
      setTotal(data.total)

      // Fix #4: fetch step counts for all workflows
      const counts = {}
      await Promise.all(
        data.workflows.map(async wf => {
          try {
            const res = await stepAPI.getByWorkflow(wf.id)
            counts[wf.id] = res.data.length
          } catch { counts[wf.id] = 0 }
        })
      )
      setStepCounts(counts)
    } catch {
      toast('Failed to load workflows', 'error')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])
  useEffect(() => { const t = setTimeout(() => load(search), 300); return () => clearTimeout(t) }, [search])

  const handleCreate = async () => {
    if (!newName.trim()) return
    setCreating(true)
    try {
      const { data } = await workflowAPI.create({ name: newName.trim() })
      toast('Workflow created!', 'success')
      navigate(`/workflows/${data.id}/edit`)
    } catch {
      toast('Failed to create workflow', 'error')
    } finally { setCreating(false) }
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this workflow and all its steps/rules?')) return
    try {
      await workflowAPI.delete(id)
      toast('Deleted', 'success')
      load(search)
    } catch { toast('Failed to delete', 'error') }
  }

  const TH = ({ children, w }) => (
    <th style={{ padding: '10px 14px', textAlign: 'left', fontSize: 11, fontFamily: "'Space Mono',monospace",
      color: '#5555aa', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 400,
      borderBottom: '1px solid #1e1e3a', width: w, whiteSpace: 'nowrap' }}>
      {children}
    </th>
  )
  const TD = ({ children, mono }) => (
    <td style={{ padding: '12px 14px', fontSize: 13, color: '#c0c0e0', verticalAlign: 'middle',
      borderBottom: '1px solid #111128', fontFamily: mono ? "'Space Mono',monospace" : "'DM Sans',sans-serif" }}>
      {children}
    </td>
  )

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 700, fontFamily: "'Space Mono',monospace", color: '#e0e0f8', margin: 0 }}>
            Workflows
          </h1>
          <p style={{ fontSize: 13, color: '#5555aa', margin: '4px 0 0' }}>{total} total · Automation Engine</p>
        </div>
        <Btn onClick={() => setShowCreate(true)}>+ New Workflow</Btn>
      </div>

      {/* Create form */}
      {showCreate && (
        <Card style={{ marginBottom: 20 }}>
          <Label>Workflow name</Label>
          <div style={{ display: 'flex', gap: 10 }}>
            <Input value={newName} onChange={setNewName} placeholder="e.g. Expense Approval" style={{ flex: 1 }} />
            <Btn onClick={handleCreate} disabled={creating}>{creating ? 'Creating...' : 'Create'}</Btn>
            <Btn variant="ghost" onClick={() => { setShowCreate(false); setNewName('') }}>Cancel</Btn>
          </div>
        </Card>
      )}

      {/* Search */}
      <div style={{ marginBottom: 16 }}>
        <Input value={search} onChange={setSearch} placeholder="Search workflows..." style={{ maxWidth: 320 }} />
      </div>

      {/* Fix #4: Table with all spec columns: ID, Name, Steps, Version, Status, Actions */}
      {loading ? (
        <div style={{ color: '#5555aa', textAlign: 'center', padding: 48 }}>Loading...</div>
      ) : workflows.length === 0 ? (
        <Card style={{ textAlign: 'center', padding: 56 }}>
          <div style={{ fontSize: 36, marginBottom: 12 }}>⚡</div>
          <div style={{ color: '#555' }}>No workflows found. Create your first one!</div>
        </Card>
      ) : (
        <Card style={{ padding: 0, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead style={{ background: '#0d0d1a' }}>
              <tr>
                <TH w="200px">ID</TH>
                <TH>Name</TH>
                <TH w="80px">Steps</TH>
                <TH w="90px">Version</TH>
                <TH w="100px">Status</TH>
                <TH w="220px">Actions</TH>
              </tr>
            </thead>
            <tbody>
              {workflows.map(wf => (
                <tr key={wf.id} style={{ transition: 'background 0.15s' }}
                  onMouseEnter={e => e.currentTarget.style.background='#0d0d1a'}
                  onMouseLeave={e => e.currentTarget.style.background='transparent'}>
                  <TD mono>
                    <span title={wf.id} style={{ color: '#5555aa', fontSize: 11 }}>
                      {wf.id.slice(0, 8)}...
                    </span>
                  </TD>
                  <TD>
                    <span style={{ fontWeight: 600, color: '#d0d0f8' }}>{wf.name}</span>
                    <div style={{ fontSize: 11, color: '#5555aa', fontFamily: "'Space Mono',monospace", marginTop: 2 }}>
                      Created {new Date(wf.createdAt).toLocaleDateString()}
                    </div>
                  </TD>
                  <TD mono>
                    <span style={{ color: '#a78bfa', fontWeight: 600 }}>{stepCounts[wf.id] ?? '—'}</span>
                  </TD>
                  <TD>
                    <Badge color="#7C3AED">v{wf.version}</Badge>
                  </TD>
                  <TD>
                    <Badge color={wf.is_active ? '#10B981' : '#6B7280'}>
                      {wf.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </TD>
                  <TD>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <Btn small variant="secondary" onClick={() => navigate(`/workflows/${wf.id}/edit`)}>Edit</Btn>
                      <Btn small onClick={() => navigate(`/workflows/${wf.id}/execute`)}>▶ Execute</Btn>
                      <Btn small variant="danger" onClick={() => handleDelete(wf.id)}>Delete</Btn>
                    </div>
                  </TD>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  )
}
