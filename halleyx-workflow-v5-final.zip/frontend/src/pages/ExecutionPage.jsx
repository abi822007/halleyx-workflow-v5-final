import { useState, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { workflowAPI, stepAPI, executionAPI } from '../services/api'
import { useToast } from '../context/ToastContext'
import { Card, Btn, Badge, Input, Label, STATUS_COLOR, STEP_TYPE_COLOR, STEP_TYPE_ICON } from '../components/UI'
import FlowVisualizer from '../components/FlowVisualizer'

export default function ExecutionPage() {
  const { id: workflowId } = useParams()
  const navigate = useNavigate()
  const { toast } = useToast()
  const logsRef = useRef(null)
  const pollRef = useRef(null)

  const [wf, setWf]         = useState(null)
  const [steps, setSteps]   = useState([])
  const [inputData, setInputData] = useState('{}')
  const [execution, setExecution] = useState(null)
  const [running, setRunning]     = useState(false)
  const [loading, setLoading]     = useState(true)

  useEffect(() => {
    Promise.all([workflowAPI.getOne(workflowId), stepAPI.getByWorkflow(workflowId)])
      .then(([wfRes, stepsRes]) => {
        setWf(wfRes.data)
        setSteps(stepsRes.data)
        // Prefill input data from schema
        const schema = wfRes.data.input_schema || {}
        setInputData(JSON.stringify(Object.fromEntries(Object.keys(schema).map(k => [k, ''])), null, 2))
      })
      .catch(() => toast('Failed to load workflow', 'error'))
      .finally(() => setLoading(false))
  }, [workflowId])

  // Auto-scroll logs
  useEffect(() => {
    if (logsRef.current) logsRef.current.scrollTop = logsRef.current.scrollHeight
  }, [execution?.logs?.length])

  // Poll execution status while running
  const startPolling = (execId) => {
    pollRef.current = setInterval(async () => {
      try {
        const { data } = await executionAPI.getOne(execId)
        setExecution(data)
        if (data.status !== 'running') {
          clearInterval(pollRef.current)
          setRunning(false)
          toast(data.status === 'completed' ? 'Execution complete!' : 'Execution failed', data.status === 'completed' ? 'success' : 'error')
        }
      } catch { clearInterval(pollRef.current); setRunning(false) }
    }, 800)
  }

  useEffect(() => () => clearInterval(pollRef.current), [])

  const handleExecute = async () => {
    try {
      const parsed = JSON.parse(inputData)
      setRunning(true)
      setExecution(null)
      const { data } = await executionAPI.execute(workflowId, parsed)
      // Start polling
      startPolling(data.execution_id)
    } catch (e) {
      toast(e.response?.data?.error || 'Invalid JSON or execution failed', 'error')
      setRunning(false)
    }
  }

  const handleCancel = async () => {
    if (!execution) return
    try {
      await executionAPI.cancel(execution.id)
      clearInterval(pollRef.current)
      setRunning(false)
      toast('Execution cancelled', 'info')
      const { data } = await executionAPI.getOne(execution.id)
      setExecution(data)
    } catch { toast('Failed to cancel', 'error') }
  }

  if (loading) return <div style={{ color: '#5555aa', textAlign: 'center', padding: 80 }}>Loading...</div>

  const completedStepIds = execution?.logs?.filter(l => l.status === 'completed').map(l => l.step_id) || []
  const statusColor = execution ? STATUS_COLOR[execution.status] : '#7070a0'

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 28 }}>
        <button onClick={() => navigate('/')} style={{ background: 'none', border: 'none', color: '#7070a0', cursor: 'pointer', fontSize: 20 }}>←</button>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, fontFamily: "'Space Mono', monospace", color: '#e0e0f8', margin: 0 }}>
            Execute Workflow
          </h1>
          <p style={{ fontSize: 13, color: '#5555aa', margin: '4px 0 0' }}>
            {wf?.name} · v{wf?.version}
          </p>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.6fr', gap: 20 }}>
        {/* Left */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <Card>
            <Label>Input data (JSON)</Label>
            <Input value={inputData} onChange={setInputData} multiline rows={9}
              style={{ fontFamily: "'Space Mono', monospace", fontSize: 12, marginBottom: 12 }}
              disabled={running} />
            <div style={{ display: 'flex', gap: 10 }}>
              <Btn onClick={handleExecute} disabled={running} style={{ flex: 1 }}>
                {running ? '⟳ Running...' : '▶ Execute'}
              </Btn>
              {running && (
                <Btn variant="danger" onClick={handleCancel}>Stop</Btn>
              )}
            </div>
          </Card>

          <Card>
            <Label>Execution flow</Label>
            <FlowVisualizer steps={steps} currentStepId={execution?.current_step_id} completedStepIds={completedStepIds} />
            {execution && (
              <div style={{ marginTop: 12, textAlign: 'center' }}>
                <Badge color={statusColor}>{execution.status}</Badge>
              </div>
            )}
          </Card>
        </div>

        {/* Right: Logs */}
        <Card>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <Label>Execution logs</Label>
            {execution && <Badge color={statusColor}>{execution.status}</Badge>}
          </div>

          {!execution && !running ? (
            <div style={{ color: '#555', fontSize: 13, textAlign: 'center', padding: 56, fontFamily: "'DM Sans', sans-serif" }}>
              <div style={{ fontSize: 36, marginBottom: 12 }}>▶</div>
              Run the workflow to see step-by-step logs here
            </div>
          ) : (
            <div ref={logsRef} style={{ maxHeight: 520, overflowY: 'auto' }}>
              {execution?.logs?.map((log, i) => (
                <div key={i} style={{ marginBottom: 18, paddingBottom: 18, borderBottom: '1px solid #1a1a30' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                    <span style={{ fontSize: 16, color: STEP_TYPE_COLOR[log.step_type] }}>
                      {STEP_TYPE_ICON[log.step_type]}
                    </span>
                    <span style={{ fontSize: 13, fontWeight: 600, color: '#d0d0f8', fontFamily: "'DM Sans', sans-serif" }}>
                      {log.step_name}
                    </span>
                    <Badge color={log.status === 'error' ? '#EF4444' : '#10B981'}>{log.status}</Badge>
                    <span style={{ marginLeft: 'auto', fontSize: 11, color: '#5555aa', fontFamily: "'Space Mono', monospace" }}>
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>

                  {log.message && (
                    <div style={{ fontSize: 12, color: '#8080c0', fontFamily: "'Space Mono', monospace", marginBottom: 8 }}>
                      {log.message}
                    </div>
                  )}

                  {log.evaluated_rules?.length > 0 && (
                    <div style={{ background: '#0a0a18', borderRadius: 6, padding: 10 }}>
                      <div style={{ fontSize: 11, color: '#5555aa', fontFamily: "'Space Mono', monospace", marginBottom: 6 }}>
                        RULES EVALUATED
                      </div>
                      {log.evaluated_rules.map((r, j) => (
                        <div key={j} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11,
                          fontFamily: "'Space Mono', monospace", color: '#7070a0', marginBottom: 3 }}>
                          <span style={{ color: r.result === 'matched' ? '#10B981' : r.result?.includes('error') ? '#EF4444' : '#444466' }}>
                            {r.result?.includes('matched') ? '✓' : r.result?.includes('error') ? '✗' : '○'}
                          </span>
                          <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {r.rule?.condition}
                          </span>
                          <Badge color={r.result?.includes('matched') ? '#10B981' : r.result?.includes('error') ? '#EF4444' : '#444466'}>
                            {r.result}
                          </Badge>
                        </div>
                      ))}
                      {log.selected_next_step && (
                        <div style={{ fontSize: 11, color: '#7C3AED', fontFamily: "'Space Mono', monospace", marginTop: 6 }}>
                          → {steps.find(s => s.id === log.selected_next_step)?.name || '(End)'}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}

              {running && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#F59E0B', fontSize: 13 }}>
                  <div className="animate-pulse-dot" style={{ width: 8, height: 8, borderRadius: '50%', background: '#F59E0B' }} />
                  Processing...
                </div>
              )}

              {execution?.status === 'completed' && (
                <div style={{ padding: 16, borderRadius: 8, background: '#10B98122', border: '1px solid #10B98144',
                  textAlign: 'center', color: '#10B981', fontFamily: "'DM Sans', sans-serif", fontWeight: 600 }}>
                  ✓ Workflow completed successfully
                </div>
              )}
              {execution?.status === 'failed' && (
                <div style={{ padding: 16, borderRadius: 8, background: '#EF444422', border: '1px solid #EF444444',
                  textAlign: 'center', color: '#EF4444', fontFamily: "'DM Sans', sans-serif", fontWeight: 600 }}>
                  ✗ Workflow failed — check rule errors above
                </div>
              )}
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}
