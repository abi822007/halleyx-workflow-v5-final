import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { stepAPI, ruleAPI } from '../services/api'
import { useToast } from '../context/ToastContext'
import { Card, Btn, Badge, Input, Label, Select, STEP_TYPE_COLOR } from '../components/UI'

export default function RuleEditorPage() {
  const { workflowId, stepId } = useParams()
  const navigate = useNavigate()
  const { toast } = useToast()

  const [step, setStep]       = useState(null)
  const [rules, setRules]     = useState([])
  const [allSteps, setAllSteps] = useState([])
  const [loading, setLoading] = useState(true)

  const [showAdd, setShowAdd] = useState(false)
  const [newRule, setNewRule] = useState({ condition: '', next_step_id: '', priority: 10 })
  const [adding, setAdding]   = useState(false)

  const [testData, setTestData]     = useState('{}')
  const [testResult, setTestResult] = useState(null)
  const [testing, setTesting]       = useState(false)

  const loadData = async () => {
    try {
      const [stepsRes, rulesRes] = await Promise.all([
        stepAPI.getByWorkflow(workflowId),
        ruleAPI.getByStep(stepId),
      ])
      const found = stepsRes.data.find(s => s.id === stepId)
      setStep(found)
      setAllSteps(stepsRes.data)
      setRules(rulesRes.data)
    } catch {
      toast('Failed to load rules', 'error')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { loadData() }, [stepId])

  const handleAdd = async () => {
    if (!newRule.condition.trim()) return
    setAdding(true)
    try {
      await ruleAPI.create(stepId, {
        condition:    newRule.condition,
        next_step_id: newRule.next_step_id || null,
        priority:     parseInt(newRule.priority) || 10,
      })
      toast('Rule added!', 'success')
      setNewRule({ condition: '', next_step_id: '', priority: 10 })
      setShowAdd(false)
      loadData()
    } catch {
      toast('Failed to add rule', 'error')
    } finally {
      setAdding(false)
    }
  }

  const handleDelete = async (ruleId) => {
    try {
      await ruleAPI.delete(ruleId)
      toast('Rule deleted', 'success')
      loadData()
    } catch {
      toast('Failed to delete', 'error')
    }
  }

  const handleTest = async () => {
    setTesting(true)
    try {
      // Test each rule client-side using the /rules/test endpoint for each
      const parsed = JSON.parse(testData)
      const results = []
      let selected = null

      for (const rule of [...rules].sort((a, b) => a.priority - b.priority)) {
        const { data } = await ruleAPI.test({ condition: rule.condition, data: parsed })
        const matched = data.result === true
        results.push({ rule, result: matched ? 'matched' : 'skipped' })
        if (matched && !selected) { selected = rule; break }
      }

      setTestResult({ selected, log: results })
    } catch (e) {
      toast(e.response?.data?.error || 'Invalid JSON', 'error')
    } finally {
      setTesting(false)
    }
  }

  if (loading) return (
    <div style={{ color: '#5555aa', textAlign: 'center', padding: 80 }}>Loading...</div>
  )

  const stepOptions = [
    { value: '', label: '(End workflow)' },
    ...allSteps.filter(s => s.id !== stepId).map(s => ({ value: s.id, label: s.name })),
  ]

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 28 }}>
        <button onClick={() => navigate(`/workflows/${workflowId}/edit`)}
          style={{ background: 'none', border: 'none', color: '#7070a0', cursor: 'pointer', fontSize: 20 }}>←</button>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, fontFamily: "'Space Mono', monospace", color: '#e0e0f8', margin: 0 }}>
            Rule Editor
          </h1>
          {step && (
            <p style={{ fontSize: 13, color: '#5555aa', margin: '4px 0 0', display: 'flex', alignItems: 'center', gap: 8 }}>
              Step: {step.name}&nbsp;
              <Badge color={STEP_TYPE_COLOR[step.step_type]}>{step.step_type}</Badge>
            </p>
          )}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 20 }}>
        {/* Rules list */}
        <Card>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <Label>Rules — evaluated by priority (low → high)</Label>
            <Btn small onClick={() => setShowAdd(true)}>+ Add Rule</Btn>
          </div>

          {showAdd && (
            <div style={{ background: '#0d0d1a', border: '1px solid #2a2a3e', borderRadius: 8, padding: 14, marginBottom: 14 }}>
              <Label>Condition (or "DEFAULT" for fallback)</Label>
              <Input value={newRule.condition} onChange={v => setNewRule(p => ({ ...p, condition: v }))}
                placeholder='department == "Engineering"' style={{ marginBottom: 8 }} />
              <Label>Next step</Label>
              <Select value={newRule.next_step_id} onChange={v => setNewRule(p => ({ ...p, next_step_id: v }))}
                options={stepOptions} style={{ width: '100%', marginBottom: 8 }} />
              <Label>Priority (lower = evaluated first)</Label>
              <Input value={String(newRule.priority)} onChange={v => setNewRule(p => ({ ...p, priority: v }))}
                placeholder="10" style={{ marginBottom: 10 }} />
              <div style={{ display: 'flex', gap: 8 }}>
                <Btn small onClick={handleAdd} disabled={adding}>{adding ? 'Adding...' : 'Add Rule'}</Btn>
                <Btn small variant="ghost" onClick={() => setShowAdd(false)}>Cancel</Btn>
              </div>
            </div>
          )}

          {rules.length === 0 ? (
            <div style={{ color: '#555', fontSize: 13, textAlign: 'center', padding: 32, fontFamily: "'DM Sans', sans-serif" }}>
              No rules — steps without rules advance sequentially by order.
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[...rules].sort((a, b) => a.priority - b.priority).map(rule => {
                const isDefault = rule.condition?.trim() === 'DEFAULT'
                const nextName  = allSteps.find(s => s.id === rule.next_step_id)?.name
                return (
                  <div key={rule.id} style={{
                    background: '#0d0d1a',
                    border: `1px solid ${isDefault ? '#7C3AED44' : '#1e1e3a'}`,
                    borderRadius: 8, padding: '12px 14px',
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <div style={{ flex: 1, marginRight: 10 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                          <span style={{ fontSize: 11, fontFamily: "'Space Mono', monospace", color: '#7070a0',
                            background: '#1a1a30', padding: '2px 6px', borderRadius: 4 }}>
                            P{rule.priority}
                          </span>
                          {isDefault && <Badge color="#7C3AED">DEFAULT</Badge>}
                        </div>
                        <div style={{ fontSize: 13, fontFamily: "'Space Mono', monospace", color: '#a0a0d8', wordBreak: 'break-all' }}>
                          {rule.condition}
                        </div>
                        <div style={{ fontSize: 12, color: '#5555aa', marginTop: 4, fontFamily: "'DM Sans', sans-serif" }}>
                          → {nextName || '(End workflow)'}
                        </div>
                      </div>
                      <Btn small variant="danger" onClick={() => handleDelete(rule.id)}>×</Btn>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </Card>

        {/* Tester + syntax help */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <Card>
            <Label>Rule tester</Label>
            <div style={{ fontSize: 12, color: '#5555aa', marginBottom: 10, fontFamily: "'DM Sans', sans-serif" }}>
              Paste execution data JSON to see which rule fires:
            </div>
            <Input value={testData} onChange={setTestData} multiline rows={5}
              style={{ fontFamily: "'Space Mono', monospace", fontSize: 12, marginBottom: 10 }} />
            <Btn onClick={handleTest} disabled={testing} style={{ width: '100%', marginBottom: 14 }}>
              {testing ? 'Testing...' : 'Run Test'}
            </Btn>

            {testResult && (
              <div>
                <div style={{ background: '#0d0d1a', borderRadius: 8, padding: 12, marginBottom: 10 }}>
                  <Label>Selected rule</Label>
                  {testResult.selected ? (
                    <div>
                      <div style={{ fontSize: 13, fontFamily: "'Space Mono', monospace", color: '#10B981' }}>
                        {testResult.selected.condition}
                      </div>
                      <div style={{ fontSize: 12, color: '#5555aa', marginTop: 4 }}>
                        → {allSteps.find(s => s.id === testResult.selected.next_step_id)?.name || '(End)'}
                      </div>
                    </div>
                  ) : (
                    <div style={{ color: '#EF4444', fontSize: 13, fontFamily: "'Space Mono', monospace" }}>
                      No rule matched
                    </div>
                  )}
                </div>

                <Label>Evaluation log</Label>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {testResult.log.map((l, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 10px',
                      borderRadius: 6, background: '#0a0a18', fontSize: 12, fontFamily: "'Space Mono', monospace" }}>
                      <span style={{ color: l.result === 'matched' ? '#10B981' : '#555566', fontSize: 14 }}>
                        {l.result === 'matched' ? '✓' : '○'}
                      </span>
                      <span style={{ color: '#8080c0', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {l.rule.condition}
                      </span>
                      <Badge color={l.result === 'matched' ? '#10B981' : '#6B7280'}>{l.result}</Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </Card>

          <Card>
            <Label>Supported syntax</Label>
            {[
              ['Comparison', 'age > 18    status == "active"'],
              ['Logic',      'a > 0 && b < 10    x == 1 || y == 2'],
              ['Strings',    'contains(name, "John")'],
              ['',           'startsWith(email, "admin")'],
              ['',           'endsWith(email, ".com")'],
              ['Fallback',   'DEFAULT  (always matches last)'],
            ].map(([k, v], i) => (
              <div key={i} style={{ marginBottom: 8 }}>
                {k && <div style={{ fontSize: 11, color: '#7070a0', fontFamily: "'Space Mono', monospace",
                  textTransform: 'uppercase', letterSpacing: '0.05em' }}>{k}</div>}
                <div style={{ fontSize: 12, color: '#8080c0', fontFamily: "'Space Mono', monospace" }}>{v}</div>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  )
}
