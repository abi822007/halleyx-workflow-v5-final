import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { workflowAPI, stepAPI } from '../services/api'
import { useToast } from '../context/ToastContext'
import { Card, Btn, Badge, Input, Label, Select, STEP_TYPE_COLOR, STEP_TYPE_ICON } from '../components/UI'
import FlowVisualizer from '../components/FlowVisualizer'

// Fix #7: convert schema object ↔ field array
function schemaToFields(obj = {}) {
  return Object.entries(obj).map(([key, val]) => ({
    key,
    type:           typeof val === 'object' ? (val.type || 'string')                                        : val,
    required:       typeof val === 'object' ? (val.required ?? false)                                       : false,
    allowed_values: typeof val === 'object' ? (val.allowed_values || []).join(', ')                         : '',
  }))
}

function fieldsToSchema(fields) {
  const obj = {}
  fields.forEach(f => {
    if (!f.key.trim()) return
    obj[f.key.trim()] = {
      type:     f.type || 'string',
      required: !!f.required,
      ...(f.allowed_values.trim()
        ? { allowed_values: f.allowed_values.split(',').map(v => v.trim()).filter(Boolean) }
        : {}),
    }
  })
  return obj
}

const TYPE_OPTIONS = [
  { value: 'string',  label: 'string'  },
  { value: 'number',  label: 'number'  },
  { value: 'boolean', label: 'boolean' },
]

export default function WorkflowEditorPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { toast } = useToast()

  const [wf,         setWf]         = useState(null)
  const [steps,      setSteps]      = useState([])
  const [wfName,     setWfName]     = useState('')
  const [fields,     setFields]     = useState([])   // Fix #7: structured schema fields
  const [loading,    setLoading]    = useState(true)
  const [saving,     setSaving]     = useState(false)
  const [showAddStep,setShowAddStep]= useState(false)
  const [newStep,    setNewStep]    = useState({ name: '', step_type: 'task' })
  const [addingStep, setAddingStep] = useState(false)

  const loadData = async () => {
    try {
      const [wfRes, stepsRes] = await Promise.all([
        workflowAPI.getOne(id),
        stepAPI.getByWorkflow(id),
      ])
      setWf(wfRes.data)
      setWfName(wfRes.data.name)
      setFields(schemaToFields(wfRes.data.input_schema || {}))
      setSteps(stepsRes.data)
    } catch { toast('Failed to load workflow', 'error') }
    finally  { setLoading(false) }
  }

  useEffect(() => { loadData() }, [id])

  const handleSave = async () => {
    setSaving(true)
    try {
      const input_schema = fieldsToSchema(fields)
      await workflowAPI.update(id, { name: wfName, input_schema })
      toast('Workflow saved!', 'success')
      loadData()
    } catch (e) {
      toast(e.response?.data?.error || 'Save failed', 'error')
    } finally { setSaving(false) }
  }

  const handleAddStep = async () => {
    if (!newStep.name.trim()) return
    setAddingStep(true)
    try {
      await stepAPI.create(id, newStep)
      toast('Step added!', 'success')
      setNewStep({ name: '', step_type: 'task' })
      setShowAddStep(false)
      loadData()
    } catch { toast('Failed to add step', 'error') }
    finally { setAddingStep(false) }
  }

  const handleDeleteStep = async (stepId) => {
    try {
      await stepAPI.delete(stepId)
      toast('Step deleted', 'success')
      loadData()
    } catch { toast('Failed to delete step', 'error') }
  }

  // Schema field helpers
  const updateField = (i, key, val) => setFields(prev => prev.map((f, idx) => idx===i ? {...f, [key]:val} : f))
  const addField    = ()            => setFields(prev => [...prev, { key:'', type:'string', required:false, allowed_values:'' }])
  const removeField = (i)           => setFields(prev => prev.filter((_,idx) => idx!==i))

  if (loading) return <div style={{ color:'#5555aa', textAlign:'center', padding:64 }}>Loading...</div>
  if (!wf)     return <div style={{ color:'#EF4444', padding:32 }}>Workflow not found</div>

  return (
    <div>
      {/* Header */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:28 }}>
        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          <button onClick={() => navigate('/')}
            style={{ background:'none', border:'none', color:'#7070a0', cursor:'pointer', fontSize:20 }}>←</button>
          <div>
            <h1 style={{ fontSize:22, fontWeight:700, fontFamily:"'Space Mono',monospace", color:'#e0e0f8', margin:0 }}>
              Workflow Editor
            </h1>
            <p style={{ fontSize:13, color:'#5555aa', margin:'4px 0 0' }}>
              {wf.name} · <Badge color="#7C3AED">V{wf.version}</Badge>
            </p>
          </div>
        </div>
        <div style={{ display:'flex', gap:10 }}>
          <Btn variant="secondary" onClick={() => navigate(`/workflows/${id}/execute`)}>▶ Execute</Btn>
          <Btn onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : 'Save'}</Btn>
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:20 }}>
        {/* Left column */}
        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>

          {/* Workflow name */}
          <Card>
            <Label>Workflow name</Label>
            <Input value={wfName} onChange={setWfName} placeholder="Workflow name" />
          </Card>

          {/* Fix #7: Structured Input Schema editor */}
          <Card>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
              <Label>Input schema</Label>
              <Btn small onClick={addField}>+ Add field</Btn>
            </div>
            <div style={{ fontSize:11, color:'#5555aa', fontFamily:"'DM Sans',sans-serif", marginBottom:12 }}>
              Define fields the workflow expects as execution input
            </div>

            {fields.length === 0 ? (
              <div style={{ color:'#444466', fontSize:12, textAlign:'center', padding:20, fontFamily:"'DM Sans',sans-serif" }}>
                No fields yet — click "+ Add field"
              </div>
            ) : (
              <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
                {/* Header row */}
                <div style={{ display:'grid', gridTemplateColumns:'1fr 90px 70px 1fr 28px', gap:6,
                  fontSize:10, color:'#5555aa', fontFamily:"'Space Mono',monospace",
                  textTransform:'uppercase', letterSpacing:'0.07em', padding:'0 2px' }}>
                  <span>Field name</span><span>Type</span><span>Required</span><span>Allowed values</span><span></span>
                </div>

                {fields.map((f, i) => (
                  <div key={i} style={{ display:'grid', gridTemplateColumns:'1fr 90px 70px 1fr 28px', gap:6, alignItems:'center' }}>
                    <Input value={f.key} onChange={v => updateField(i,'key',v)} placeholder="field_name" style={{ fontSize:12 }} />
                    <Select value={f.type} onChange={v => updateField(i,'type',v)} options={TYPE_OPTIONS}
                      style={{ fontSize:12, padding:'6px 8px', width:'100%' }} />
                    <div style={{ display:'flex', justifyContent:'center' }}>
                      <input type="checkbox" checked={f.required} onChange={e => updateField(i,'required',e.target.checked)}
                        style={{ width:16, height:16, cursor:'pointer', accentColor:'#7C3AED' }} />
                    </div>
                    <Input value={f.allowed_values} onChange={v => updateField(i,'allowed_values',v)}
                      placeholder="val1, val2 (optional)" style={{ fontSize:11 }} />
                    <button onClick={() => removeField(i)}
                      style={{ background:'#EF444422', border:'1px solid #EF444444', borderRadius:4,
                        color:'#EF4444', cursor:'pointer', fontSize:14, width:28, height:28 }}>×</button>
                  </div>
                ))}
              </div>
            )}

            {/* JSON preview */}
            {fields.filter(f=>f.key.trim()).length > 0 && (
              <details style={{ marginTop:14 }}>
                <summary style={{ fontSize:11, color:'#5555aa', fontFamily:"'Space Mono',monospace",
                  cursor:'pointer', textTransform:'uppercase', letterSpacing:'0.07em' }}>
                  Preview JSON
                </summary>
                <pre style={{ background:'#0a0a18', borderRadius:6, padding:10, fontSize:11,
                  fontFamily:"'Space Mono',monospace", color:'#8080c0', margin:'8px 0 0', overflowX:'auto' }}>
                  {JSON.stringify(fieldsToSchema(fields), null, 2)}
                </pre>
              </details>
            )}
          </Card>

          {/* Flow preview */}
          <Card>
            <Label>Flow preview</Label>
            <FlowVisualizer steps={steps} />
          </Card>
        </div>

        {/* Right column — Steps */}
        <Card>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:16 }}>
            <Label>Steps ({steps.length})</Label>
            <Btn small onClick={() => setShowAddStep(true)}>+ Add Step</Btn>
          </div>

          {showAddStep && (
            <div style={{ background:'#0d0d1a', border:'1px solid #2a2a3e', borderRadius:8, padding:14, marginBottom:14 }}>
              <Label>Step name</Label>
              <Input value={newStep.name} onChange={v => setNewStep(p=>({...p,name:v}))}
                placeholder="e.g. Manager Approval" style={{ marginBottom:8 }} />
              <Label>Type</Label>
              <Select value={newStep.step_type} onChange={v => setNewStep(p=>({...p,step_type:v}))}
                options={[{value:'task',label:'Task'},{value:'approval',label:'Approval'},{value:'notification',label:'Notification'}]}
                style={{ width:'100%', marginBottom:10 }} />
              <div style={{ display:'flex', gap:8 }}>
                <Btn small onClick={handleAddStep} disabled={addingStep}>{addingStep?'Adding...':'Add'}</Btn>
                <Btn small variant="ghost" onClick={() => setShowAddStep(false)}>Cancel</Btn>
              </div>
            </div>
          )}

          {steps.length === 0 ? (
            <div style={{ color:'#555', fontSize:13, textAlign:'center', padding:32, fontFamily:"'DM Sans',sans-serif" }}>
              Add your first step above
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              {steps.map((step, i) => {
                const color = STEP_TYPE_COLOR[step.step_type]
                return (
                  <div key={step.id} style={{ display:'flex', alignItems:'center', gap:12,
                    padding:'10px 14px', borderRadius:8, background:'#0d0d1a', border:'1px solid #1e1e3a' }}>
                    <span style={{ fontSize:18, color, minWidth:24 }}>{STEP_TYPE_ICON[step.step_type]}</span>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:13, fontWeight:600, color:'#d0d0f8', fontFamily:"'DM Sans',sans-serif" }}>
                        {i+1}. {step.name}
                      </div>
                      <div style={{ fontSize:11, color:'#5555aa', fontFamily:"'Space Mono',monospace" }}>
                        {step.step_type}
                      </div>
                    </div>
                    <Btn small variant="secondary"
                      onClick={() => navigate(`/workflows/${id}/steps/${step.id}/rules`)}>
                      Rules
                    </Btn>
                    <Btn small variant="danger" onClick={() => handleDeleteStep(step.id)}>×</Btn>
                  </div>
                )
              })}
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}
