import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom'
import { ToastProvider } from './context/ToastContext'
import WorkflowListPage   from './pages/WorkflowListPage'
import WorkflowEditorPage from './pages/WorkflowEditorPage'
import RuleEditorPage     from './pages/RuleEditorPage'
import ExecutionPage      from './pages/ExecutionPage'
import AuditLogsPage      from './pages/AuditLogsPage'

const NAV = [
  { to: '/',      label: '⚡ Workflows' },
  { to: '/audit', label: '📋 Audit Logs' },
]

export default function App() {
  return (
    <ToastProvider>
      <BrowserRouter>
        <div className="min-h-screen bg-[#080814] text-white flex flex-col">

          {/* ── Header ── */}
          <header className="border-b border-[#1a1a30] bg-[#0d0d1a] px-8 h-14 flex items-center gap-8 shrink-0">
            <span className="font-mono font-bold text-[#a78bfa] text-base tracking-tight flex items-center gap-2">
              <span className="text-xl">⚡</span> HALLEYX
            </span>
            <div className="w-px h-5 bg-[#1e1e3a]" />
            <nav className="flex gap-1">
              {NAV.map(({ to, label }) => (
                <NavLink
                  key={to}
                  to={to}
                  end={to === '/'}
                  className={({ isActive }) =>
                    `px-3 py-1.5 rounded-md text-sm font-medium transition-all duration-150 ${
                      isActive
                        ? 'bg-[#1e1e3a] text-[#a78bfa]'
                        : 'text-[#7070a0] hover:text-[#a0a0c8]'
                    }`
                  }
                >
                  {label}
                </NavLink>
              ))}
            </nav>
            <span className="ml-auto text-xs text-[#2a2a4a] font-mono">
              WORKFLOW AUTOMATION ENGINE v1.0
            </span>
          </header>

          {/* ── Main ── */}
          <main className="flex-1 px-10 py-8 max-w-[1200px] w-full mx-auto">
            <Routes>
              <Route path="/"                              element={<WorkflowListPage />} />
              <Route path="/workflows/:id/edit"           element={<WorkflowEditorPage />} />
              <Route path="/workflows/:wfId/steps/:stepId/rules" element={<RuleEditorPage />} />
              <Route path="/workflows/:id/execute"        element={<ExecutionPage />} />
              <Route path="/audit"                        element={<AuditLogsPage />} />
            </Routes>
          </main>

        </div>
      </BrowserRouter>
    </ToastProvider>
  )
}
