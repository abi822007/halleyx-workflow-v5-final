import axios from 'axios'

// Directly target backend — works on all setups including Windows
const api = axios.create({
  baseURL: 'http://localhost:5000/api',
  headers: { 'Content-Type': 'application/json' },
  withCredentials: false,
})

// Response interceptor for debugging
api.interceptors.response.use(
  (res) => res,
  (err) => {
    console.error('API Error:', err?.response?.data || err.message)
    return Promise.reject(err)
  }
)

// ── Workflows ──────────────────────────────────────────────
export const workflowAPI = {
  getAll:        (params)     => api.get('/workflows', { params }),
  getOne:        (id)         => api.get(`/workflows/${id}`),
  create:        (data)       => api.post('/workflows', data),
  update:        (id, data)   => api.put(`/workflows/${id}`, data),
  delete:        (id)         => api.delete(`/workflows/${id}`),
}

// ── Steps ──────────────────────────────────────────────────
export const stepAPI = {
  getByWorkflow: (wfId)       => api.get(`/workflows/${wfId}/steps`),
  create:        (wfId, data) => api.post(`/workflows/${wfId}/steps`, data),
  update:        (id, data)   => api.put(`/steps/${id}`, data),
  delete:        (id)         => api.delete(`/steps/${id}`),
}

// ── Rules ──────────────────────────────────────────────────
export const ruleAPI = {
  getByStep:     (stepId)       => api.get(`/steps/${stepId}/rules`),
  create:        (stepId, data) => api.post(`/steps/${stepId}/rules`, data),
  update:        (id, data)     => api.put(`/rules/${id}`, data),
  delete:        (id)           => api.delete(`/rules/${id}`),
  test:          (data)         => api.post('/rules/test', data),
}

// ── Executions ─────────────────────────────────────────────
export const executionAPI = {
  execute: (wfId, data) => api.post(`/workflows/${wfId}/execute`, data),
  getAll:  (params)     => api.get('/executions', { params }),
  getOne:  (id)         => api.get(`/executions/${id}`),
  cancel:  (id)         => api.post(`/executions/${id}/cancel`),
  retry:   (id)         => api.post(`/executions/${id}/retry`),
}

export default api
