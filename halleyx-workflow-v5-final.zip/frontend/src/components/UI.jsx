// ─── Shared UI Components ────────────────────────────────────────────────────

export const Card = ({ children, style = {}, className = '' }) => (
  <div
    className={className}
    style={{
      background: '#111128',
      border: '1px solid #1e1e3a',
      borderRadius: 10,
      padding: '20px 24px',
      ...style,
    }}
  >
    {children}
  </div>
)

export const Label = ({ children }) => (
  <div style={{
    fontSize: 11,
    fontFamily: "'Space Mono', monospace",
    color: '#7070a0',
    textTransform: 'uppercase',
    letterSpacing: '0.1em',
    marginBottom: 6,
  }}>
    {children}
  </div>
)

export const Badge = ({ children, color }) => (
  <span style={{
    display: 'inline-flex',
    alignItems: 'center',
    padding: '2px 8px',
    borderRadius: 20,
    fontSize: 11,
    fontWeight: 600,
    fontFamily: "'Space Mono', monospace",
    background: color + '22',
    color,
    border: `1px solid ${color}44`,
    textTransform: 'uppercase',
    letterSpacing: '0.05em',
    whiteSpace: 'nowrap',
  }}>
    {children}
  </span>
)

export const Btn = ({ children, onClick, variant = 'primary', small = false, disabled = false, style: s = {}, type = 'button' }) => {
  const bg = disabled
    ? '#2a2a3e'
    : variant === 'danger'    ? '#EF4444'
    : variant === 'ghost'     ? 'transparent'
    : variant === 'secondary' ? '#1e1e3e'
    : '#7C3AED'

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      style={{
        padding: small ? '4px 12px' : '8px 18px',
        borderRadius: 6,
        fontSize: small ? 12 : 13,
        fontFamily: "'DM Sans', sans-serif",
        fontWeight: 500,
        cursor: disabled ? 'not-allowed' : 'pointer',
        border: variant === 'ghost' ? '1px solid #2a2a3e' : 'none',
        background: bg,
        color: disabled ? '#555' : '#fff',
        transition: 'opacity 0.15s',
        opacity: disabled ? 0.6 : 1,
        ...s,
      }}
    >
      {children}
    </button>
  )
}

export const Input = ({ value, onChange, placeholder, style: s = {}, multiline = false, rows = 3, disabled = false }) =>
  multiline ? (
    <textarea
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      rows={rows}
      disabled={disabled}
      style={{
        width: '100%',
        background: '#0d0d1a',
        border: '1px solid #2a2a3e',
        borderRadius: 6,
        color: '#e0e0f0',
        padding: '8px 12px',
        fontSize: 13,
        fontFamily: "'Space Mono', monospace",
        resize: 'vertical',
        boxSizing: 'border-box',
        ...s,
      }}
    />
  ) : (
    <input
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      disabled={disabled}
      style={{
        width: '100%',
        background: '#0d0d1a',
        border: '1px solid #2a2a3e',
        borderRadius: 6,
        color: '#e0e0f0',
        padding: '8px 12px',
        fontSize: 13,
        fontFamily: "'DM Sans', sans-serif",
        boxSizing: 'border-box',
        ...s,
      }}
    />
  )

export const Select = ({ value, onChange, options, style: s = {} }) => (
  <select
    value={value}
    onChange={e => onChange(e.target.value)}
    style={{
      background: '#0d0d1a',
      border: '1px solid #2a2a3e',
      borderRadius: 6,
      color: '#e0e0f0',
      padding: '8px 12px',
      fontSize: 13,
      fontFamily: "'DM Sans', sans-serif",
      cursor: 'pointer',
      ...s,
    }}
  >
    {options.map(o => (
      <option key={o.value} value={o.value}>{o.label}</option>
    ))}
  </select>
)

export const Spinner = () => (
  <div style={{
    width: 20, height: 20, borderRadius: '50%',
    border: '2px solid #2a2a3e',
    borderTopColor: '#7C3AED',
    animation: 'spin 0.7s linear infinite',
  }} />
)

export const STEP_TYPE_COLOR = { task: '#3B82F6', approval: '#F59E0B', notification: '#10B981' }
export const STEP_TYPE_ICON  = { task: '⚙', approval: '✓', notification: '✉' }
export const STATUS_COLOR    = { running: '#F59E0B', completed: '#10B981', failed: '#EF4444', cancelled: '#6B7280' }
