import { STEP_TYPE_COLOR, STEP_TYPE_ICON } from './UI'

export default function FlowVisualizer({ steps = [], currentStepId = null, completedStepIds = [] }) {
  if (!steps.length) {
    return (
      <div style={{ color: '#555', fontSize: 13, textAlign: 'center', padding: 32, fontFamily: "'DM Sans', sans-serif" }}>
        No steps yet
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '12px 0', gap: 0 }}>
      {steps.map((step, i) => {
        const isActive    = step.id === currentStepId
        const isDone      = completedStepIds.includes(step.id)
        const color       = STEP_TYPE_COLOR[step.step_type]

        return (
          <div key={step.id} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '10px 20px', borderRadius: 8, minWidth: 230,
              background: isActive ? color + '22' : isDone ? '#10B98111' : '#0d0d1a',
              border: `1.5px solid ${isActive ? color : isDone ? '#10B98155' : '#2a2a3e'}`,
              boxShadow: isActive ? `0 0 18px ${color}44` : 'none',
              transition: 'all 0.3s',
            }}>
              <span style={{ fontSize: 18, color: isDone ? '#10B981' : color }}>
                {isDone ? '✓' : STEP_TYPE_ICON[step.step_type]}
              </span>
              <div style={{ flex: 1 }}>
                <div style={{
                  fontSize: 13, fontWeight: 600,
                  color: isActive ? color : isDone ? '#10B981' : '#c0c0e0',
                  fontFamily: "'DM Sans', sans-serif",
                }}>
                  {i + 1}. {step.name}
                </div>
                <div style={{ fontSize: 11, color: '#5555aa', fontFamily: "'Space Mono', monospace" }}>
                  {step.step_type}
                </div>
              </div>
              {isActive && (
                <div className="animate-pulse-dot" style={{
                  width: 8, height: 8, borderRadius: '50%', background: color,
                }} />
              )}
            </div>

            {i < steps.length - 1 && (
              <div style={{ width: 2, height: 24, background: '#2a2a3e' }} />
            )}
          </div>
        )
      })}
    </div>
  )
}
